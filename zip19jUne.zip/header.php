<?php 
include 'config/config.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Mega App</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="<?php echo $rot ?>html/css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div id="wrapper">
	<!--top-bar-->
	<div class="top-bar-bg">
		<div class="container">
			<ul class="top-nav">
				<li><a href="<?php echo $rot ?>" title="Home">Home</a></li>
				<li><a href="<?php echo $rot.'/dialog.php'?>" title="File Manager">File Manager</a></li>
           <!--
				<li><a href="<?php   //echo $rot.'/facebook/fb.php'?>" title="Facebook">Facebook</a></li>
				<li><a href="<?php //echo $rot.'/twitter/'?>" title="Twitter">Twitter</a></li> 
              -->
              <?php 
              if ($_SESSION['admin'] == 1)
              {
              	?>		<li><a href="<?php echo $rot.'/admin/'?>" title="Admin Panel">Admin Panel</a></li> <?php
              }?>

			</ul>
		</div>
	</div>
</div>
