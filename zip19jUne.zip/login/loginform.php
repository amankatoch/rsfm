<?php
include '../header.php';
?>
  
<script>

//
//	jQuery Validate example script
//
//	Prepared by David Cochran
//
//	Free for your use -- No warranties, no guarantees!
//

$(document).ready(function(){
  
	// Validate
	// http://bassistance.de/jquery-plugins/jquery-plugin-validation/
	// http://docs.jquery.com/Plugins/Validation/
	// http://docs.jquery.com/Plugins/Validation/validate#toptions

		$('#contact-form').validate({
	    rules: {
	      name: {
	        minlength: 2,
	        required: true
	      },
	      email: {
	        required: true,
	        email: true
	      },
	      subject: {
	      	minlength: 2,
	        required: true
	      },
	      message: {
	        minlength: 2,
	        required: true
	      }
	    },
			highlight: function(element) {
				$(element).closest('.control-group').removeClass('success').addClass('error');
			},
			success: function(element) {
				element
				.text('OK!').addClass('valid')
				.closest('.control-group').removeClass('error').addClass('success');
			}
	  });
	  
	  
	
	  

}); // end document.ready
</script>
</head>
<style>
#menu a {
  float: left;
  margin-top: 6px;
  width: 79px;
}
#menu {
  float: right;
  margin-right: 116px;
}
</style>
<body>
	
	<div id=head span=class12 style="background:black;height:40px;">
	<div id=menu>
<a align=center href="loginform.php"><button  class="btn">Sign in</button></a>	

<a align=center href="registerform.php"><button  class="btn">Registration</button></a>	
	
	</div>
	</div>
	<div class="span12">
	<h3>Sign In </h3>
	</div><br><br>
<div id="error">

<?php
if(isset($_GET['error']))
{
	echo '<h3 style="color:red;">Email/Password invalid Please enter again</h3>';
}
elseif(isset($_GET['success']))

{
	echo '<h3 style="color:red;">Congratulation you have sucessfully registered</h3>';
}
else{}


?>
</div>	
<form method=post action="login.php" class="well form" id="contact-form"> 
 <fieldset>
  
		    <div class="control-group">
	        <label class="control-label" for="email">Email Address
		    <div class="controls">
	        <input type="text" class="input-xlarge" name="email" id="email">
		    </div></label>
            </div>
            <div class="control-group">
		    <label class="control-label" for="pwd">Password
     	    <div class="controls">
	        <input type="password" class="input-xlarge" name="pwd" id="pwd">
		    </div></label>
            </div>
   <div class="checkbox">
    <label>
      <input type="checkbox"> Remember me
    </label>
  </div>
 
<button type="submit" class="btn btn-info">Sign in</button>  
</fieldset>
</form>  
<a href=forgot.php>Forgot Password</a>

</body>


</html>

