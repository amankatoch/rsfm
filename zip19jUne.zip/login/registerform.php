<?php
include '../header.php';
?>


<script>

//
//	jQuery Validate example script
//
//	Prepared by David Cochran
//
//	Free for your use -- No warranties, no guarantees!
//
$(function () {
$(document).ready(function(){
  
	// Validate
	// http://bassistance.de/jquery-plugins/jquery-plugin-validation/
	// http://docs.jquery.com/Plugins/Validation/
	// http://docs.jquery.com/Plugins/Validation/validate#toptions

		$('#contact-form').validate({
	    rules: {
	      name: {
	        minlength: 2,
	        required: true
	      },
	      email: {
	        required: true,
	        email: true
	      },
	      subject: {
	      	minlength: 2,
	        required: true
	      },
	      message: {
	        minlength: 2,
	        required: true
	      }
	    },
			highlight: function(element) {
				$(element).closest('.control-group').removeClass('success').addClass('error');
			},
			success: function(element) {
				element
				.text('OK!').addClass('valid')
				.closest('.control-group').removeClass('error').addClass('success');
			}
	  });
	  
	  
	
	  

}); // end document.ready

});
</script>




</head>
<style>
#menu a {
  float: left;
  margin-top: 6px;
  width: 79px;
}
#menu {
  float: right;
  margin-right: 116px;
}
</style>
<body>
	
	<div id=head span=class12 style="background:black;height:40px;">
	<div id=menu>
<a align=center href="loginform.php"><button  class="btn">Sign in</button></a>	

<a align=center href="registerform.php"><button  class="btn">Registration</button></a>	
	
	</div>
	</div> <fieldset>
	<div id=info><h3>Create your account</h3></div> 
	<div id="error">

<?php
if(isset($_GET['error']))
{
	echo '<h3 style="color:red;">Email already exists</h3>';
}

?>

</div>
	
	       <form method=get action="register.php" class="well form" id="contact-form">  
           <fieldset>
 <div class="control-group">  Name     <input type="text" class="input-large" name="name"> </div> 
  <div class="control-group"> E Mail   <input type="text" class="input-large" name="email"> </div> 
  
  Password <input type="password" class="input-large" name="pwd">  <br>
  
  
 
  <button type="submit" class="btn">Sign Up</button>  
</fieldset>
</form>  

</body>


</html>

