<?php
include_once '../config/config.php'; /* Database Connection Setup */
?>


<?php
include '../header.php';

if(isset($_POST['email']))
{
	$email=$_POST['email'];
	echo $email;
    $qry="select Passwrd from user_registration where email='$email'";
    $run=mysql_query($qry);
    while($row=mysql_fetch_array($run)){
	$secre=$row['Passwrd'];
	$actual_link = "http://$_SERVER[HTTP_HOST]/Backupall/megaApp/rsfm/login/changePwd.php".'?sec='.$email.'&token='.$secre;
	$message = $actual_link;
    mail($email, 'Change Password', $message);
    echo '<h4>Email has been send to your mail id please check</h4>';
}

}
else
{


echo '<h3>Please enter your email address and we will send you the password</h3>';
echo '</br>';
echo '<form name=forgo method=post>';
echo '<input type=text name=email id=email value=>';
echo '</br>';
echo '<input type=submit>';
echo '</form>';
}
?>
</body>
</html>