<?php
include_once '../config/config.php';
include '../header.php';

	$u_email = $_GET['sec'];
	$new_pwd  = md5($_POST['pw']);	
	
if(isset($_POST['pw']))
{
	$q = "select Email from user_registration where Email = '".addslashes($u_email)."' limit 1";
	$result = mysql_query($q);
	$row = mysql_num_rows($result);  
	if($row > 0) {
	     $qry = "update user_registration set Passwrd = '".addslashes($new_pwd)."' WHERE Email = '".addslashes($u_email)."'";
 	     $res = mysql_query($qry);		
	     $output=array("Response"=>"success");	
	     echo '<h2>Passwrd changed sucessfully</h2>';
	}
	else {	     
	     $output=array("Response"=>"error");
	}


 }
 else
 {
echo '<form id=changepw method=post>';
echo '<input type=text name=pw>';
echo '<input type=text name=repw>';
echo '<input type=submit class="btn btn-info" value="change password">';
echo '<form>';

}


?>
