<?php
	include_once '../config/config.php'; /* Database Connection Setup */
    session_start();
/* Web Service of User Login */
   
	//$u_id = $REQUEST['uid'];   
	$login_email = $_REQUEST['email'];
	$login_pwd  = $_REQUEST['pwd'];
	$q = "select * from user_registration where Email = '".addslashes($login_email)."' and Passwrd = '".addslashes(md5($login_pwd))."' limit 1";
	$result = mysql_query($q);
	while($run=mysql_fetch_array($result))
	{
		$userid=$run['Id'];
		$_SESSION['user_name']=$run['Name'];
		$_SESSION['user_email']=$run['Email'];
		$isadmin=$run['admin'];
	}
	
	$row = mysql_num_rows($result); 
	
	 
	if($row > 0) {
	 $output=array("Response"=>"success");
	 if(session_id() == '')
     {
	 echo 'seesion not set';
	 exit;
	 }
	 
	 
	 $_SESSION['user_id']=$userid;
     $_SESSION['user_id'];

      if($isadmin==0)
      {
	 header("Location: ../dialog.php");
	  }
	 else
	 {  $_SESSION['admin']=1;
	 	header("Location:../admin/");
	 }
	 
	}
	else {
	 $output=array("Response"=>"error");
	 
	 
		 header("Location: loginform.php?error=1");
	}
	echo json_encode($output);

?>
