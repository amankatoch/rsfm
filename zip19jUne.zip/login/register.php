<?php

	include_once '../config/config.php'; /* Database Connection Setup */

/* Web Service of User Registration */

	$output = "";     
	$activation = md5(uniqid(rand(), true));
   
	$user_name  = $_REQUEST['name'];
	$user_email = $_REQUEST['email'];
	$email_pwd  = $_REQUEST['pwd'];
	$encrypt_pwd = md5($email_pwd);	
        
	$q = "select * from user_registration where Email = '".addslashes($user_email)."' limit 1";
	$result = mysql_query($q);
	$row = mysql_num_rows($result);  
	if($row > 0) {
	     $output=array("Response"=>"error");	
	}
	else {
	    $sql = "insert into user_registration(Name, Email, Passwrd, Activation) values ('$user_name', '$user_email', '$encrypt_pwd', '$activation')";
 	    $res = mysql_query($sql);	
	    $uid = mysql_insert_id();
	    $message = " To activate your account, please click on this link:\n\n";
        $message .= 'http://www.clickripplesolutions.com/megaApp/Activate.php?email=' . addslashes($user_email) . "&key=$activation";
        mail($user_email, 'Registration Confirmation', $message);
	    $output=array("Response"=>"success" , "userid"=>$uid);
	}
	
	
	if($output[Response]=='success')
	{
		//echo 'this is sucess';
		
		

		header("Location:loginform.php?success=1");
		exit();
	}
	else
	{  
		 header("Location:registerform.php?error=1");
		 exit();
		//echo 'this is faliure';
	}
	
	
	
	
?>
