<?php
include 'config/config.php';
include 'header.php';
echo '<div class="container">';
echo 'howdy admin !';

echo '<h3>all users</h3><br> ';
echo '<table class="table table-striped">';
echo '<th>Name </th> <th>Email</th>';
$qry= " select * from user_registration";
$run=mysql_query($qry);

while ($row=mysql_fetch_array($run))
{  
	echo '<tr>'; 
    echo '<td>'.$row['Name'].'</td><td> <span style="color:green;">'.$row['Email'].'</span></td>';
    echo '</tr>';

}

echo '</table>';
echo '</div>';
?>
