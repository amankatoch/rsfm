<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'sCo0j4Dm7BKhiiIYd6h1LNPHU');
define('CONSUMER_SECRET', 'Q5NA8AnbgjB6h3ifxPbar6nUaBzZL51iDawx6Y1BWURsDwnvb9');
define('OAUTH_CALLBACK', 'http://www.clickripplesolutions.com/megaApp/rsfm/twitter/callback.php');

