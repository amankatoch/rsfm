<?php
session_start();
require_once('twitteroauth/twitteroauth.php');
require_once('config.php');


$token_credentials = $connection->getAccessToken($_REQUEST['oauth_verifier']);
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $token_credentials['oauth_token'],
$token_credentials['oauth_token_secret']);

$account = $connection->get('account/verify_credentials');
echo '<pre>';
print_r($account);

?>
