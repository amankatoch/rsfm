<?php
ini_set('display_errors', 1);
require_once('TwitterAPIExchange.php');

/** Set access tokens here - see: https://dev.twitter.com/apps/ **/
$settings = array(
    'oauth_access_token' => "2485288956-7ATKrCzEmQ0P1cCs0YZv33F0ddGbi8DqKLGI5sJ",
    'oauth_access_token_secret' => "buDEIfCrm4SRjwlyGyB7KmvWzpzdvvWuWYVniusPTb64F",
    'consumer_key' => "sCo0j4Dm7BKhiiIYd6h1LNPHU",
    'consumer_secret' => "Q5NA8AnbgjB6h3ifxPbar6nUaBzZL51iDawx6Y1BWURsDwnvb9"
);

/** URL for REST request, see: https://dev.twitter.com/docs/api/1.1/ **/
$url = 'https://api.twitter.com/1.1/blocks/create.json';
$requestMethod = 'GET';

/** POST fields required by the URL above. See relevant docs as above **/
$postfields = array(
    'screen_name' => 'aman_katoch', 
    'skip_status' => '1'
);

/** Perform a POST request and echo the response **/
$twitter = new TwitterAPIExchange($settings);
echo $twitter->buildOauth($url, $requestMethod)
             ->setPostfields($postfields)
             ->performRequest();

/** Perform a GET request and echo the response **/
/** Note: Set the GET field BEFORE calling buildOauth(); **/
$url = 'https://api.twitter.com/1.1/followers/ids.json';
$getfield = '?screen_name=aman_katoch';
$requestMethod = 'GET';
$twitter = new TwitterAPIExchange($settings);
echo $twitter->setGetfield($getfield)
             ->buildOauth($url, $requestMethod)
             ->performRequest();
