<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'CONSUMER_KEY_HERE');
define('CONSUMER_SECRET', 'CONSUMER_SECRET_HERE');
define('OAUTH_CALLBACK', 'http://example.com/twitteroauth/callback.php');
