<?php
require 'src/facebook.php';
session_destroy();
$url="fb.php";
header('Location: '.$url);
?>
