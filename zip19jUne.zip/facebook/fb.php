

<?php
/**
 * Copyright 2011 Facebook, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
error_reporting(0);
require 'src/facebook.php';

// Create our Application instance (replace this with your appId and secret).
$facebook = new Facebook(array(
  'appId'  => '1421355304799802',
  'secret' => '1731b9cbd4bcaa281346310e909d7507',
  'cookie' =>'true',
));

// Get User ID


function redirect_to_login($facebook){
    $login_url = $facebook->getLoginUrl(array(
        'scope' => 'email','user_status','publish_stream','user_photos','user_photo_video_tags',
    ));
    header('Location: '.$login_url);
    exit;
}

$uid=$facebook->getUser();

if (!$uid ) { // see check_perms below
    // send users to login/auth page if they are not logged in, 
    // or not installed the app, 
    // or don't have all the perms we need
    redirect_to_login($facebook);
}
$user = $facebook->getUser();


// We may or may not have this data based on whether the user is logged in.
//
// If we have a $user id here, it means we know the user is logged into
// Facebook, but we don't know if the access token is valid. An access
// token is invalid if the user logged out of Facebook.

if ($user) {
  try {
    // Proceed knowing you have a logged in user who's authenticated.
    $user_profile = $facebook->api('/me/feed');
  } catch (FacebookApiException $e) {
    error_log($e);
    $user = null;
  }
}


/* make the API call */
$response1 = $facebook->api(
    "/me/photos"
);
/* handle the result */

// Login or logout url will be needed depending on current user state.


// This call will always work since we are fetching public data.


?>
<!doctype html>
<html xmlns:fb="http://www.facebook.com/2008/fbml">
  <head>
    <title>php-sdk</title>
    <style>
      body {
        font-family: 'Lucida Grande', Verdana, Arial, sans-serif;
      }
      h1 a {
        text-decoration: none;
        color: #3b5998;
      }
      h1 a:hover {
        text-decoration: underline;
      }
    </style>
  
  
  
<link href="../html/css/style.css" rel="stylesheet" type="text/css" />
 <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css" />
        <link href="../css/bootstrap-lightbox.min.css" rel="stylesheet" type="text/css" />
        <link href="../css/style.css" rel="stylesheet" type="text/css" />
	<link href="../css/dropzone.min.css" type="text/css" rel="stylesheet" />
	<link href="../css/base.css" type="text/css" rel="stylesheet" />
	<link href="../css/twitter/bootstrap.css" rel="stylesheet">
   <link href="../css/twitter/responsive.css" rel="stylesheet">
	<link href="../html/css/style.css" rel="stylesheet">




  </head>
  <body>
	  	<div class="top-bar-bg">
		<div class="container">
			<ul class="top-nav">
				<li><a href="../index.php" title="Home">Home</a></li>
				<li><a href="../dialog.php" title="File Manager">File Manager</a></li>
				<li><a href="#" title="Facebook">Facebook</a></li>
				<li><a href="#" title="Twitter">Twitter</a></li> 
			</ul>
		</div>
	   </div>
	   
	   <div class="container">
  

    <?php if ($user): ?>
      <a href="<?php echo $logoutUrl; ?>">Logout</a>
    <?php else: ?>
      <div>
        Check the login status using OAuth 2.0 handled by the PHP SDK:
        <a href="<?php echo $statusUrl; ?>">Check the login status</a>
      </div>
      <div>
        Login using OAuth 2.0 handled by the PHP SDK:
        <a href="<?php echo $loginUrl; ?>">Login with Facebook</a>
      </div>
    <?php endif ?>

    
    <pre><?php  ?></pre>

    <?php if ($user): ?>
     <div  id=row>
       <div class=span11>
       </div>
      <div class=span1><h3>You</h3>
      <img src="https://graph.facebook.com/<?php echo $user; ?>/picture">
      </div>
     </div>
     <!-- <h3>Your User Object (/mes)</h3>
      <pre><?php  ?></pre> -->

    <?php else: ?>
      <strong><em>You are not Connected.</em></strong>
    <?php endif ?>
      
      <div id=wallposts class=span6>
      <span class="label label-info"><h2>Your Wall Posts</h2></span>

       <?php 
       
       $no_of_feeds=sizeof($user_profile['data']);
	 
	 
	 for ($i=0;$i<$no_of_feeds;$i++)
	 {
		 
	?>
	<div class="alert alert-block alert-info">
	<img src="<?php echo $user_profile['data'][$i]['picture'];?>">
	<div id=message><?php echo $user_profile['data'][$i]['message'];?></div>
	<div id=story><?php echo $user_profile['data'][$i]['story'];?></div>
    <div id=name><?php echo $user_profile['data'][$i]['description'];?></div>  	
	
	
	<br>
	</div>
	<?php
    
    
     }
     
       echo '<pre>';
	 // print_r($user_profile);
  
       
       ?>
      
      </div>
</div>
  </body>
</html>
