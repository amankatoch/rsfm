<?php
include 'header.php';
?>

	<!--boday area-->
	<div class="container">
		<div class="body-area">
			<div class="joli-source isotope-item">
				<div class="main">
					
					<a href="dialog.php" ><div class="banner box fileman"><h3>File Manager</h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							Upload and share files .
						</p>
				     </a>
				</div>
				<div class="main">
					
				<!--
				<a href="facebook/fb.php" >	<div class="banner box facebook"><h3>Facebook</h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							Facebook on go.
						</p>
						</a>
				</div>
				<div class="main">
							<a href="twitter/" >	<div class="banner box twitter"><h3>Twitter</h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							Twitter tweets . 
						</p>
						</a>
				</div>
				<div class="main">
					<div class="banner box"><h3><a href="https://www.box.com" target="_blank">Box</a></h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							10GB minimum for your photos, videos, music, and documents.
						</p>
				</div>
             -->

			</div>
		</div>
   <div id=login>
   <a href=dialog.php> <button id=login class="btn btn-info">Login</button></a>  <a href=login/registerform.php> <button class="btn btn-info" id=signup>Signup</button></a>
   </div>

		<!--/boday area-->
	</div>	
  	
</div>
</body>
</html>
