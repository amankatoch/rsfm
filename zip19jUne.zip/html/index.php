<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="wrapper">
	<!--top-bar-->
	<div class="top-bar-bg">
		<div class="container">
			<ul class="top-nav">
				<li><a href="#" title="Home">Home</a></li>
				<li><a href="../index.php" title="File Manager">File Manager</a></li>
				<li><a href="#" title="Facebook">Facebook</a></li>
				<li><a href="#" title="Twitter">Twitter</a></li> 
			</ul>
		</div>
	</div>
	<!--boday area-->
	<div class="container">
		<div class="body-area">
			<div class="joli-source isotope-item">
				<div class="main">
					
					<a href="../index.php" ><div class="banner box fileman"><h3>File Manager</h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							Upload and share files .
						</p>
				     </a>
				</div>
				<div class="main">
					
				<a href="https://www.box.com" target="_blank">	<div class="banner box facebook"><h3>Facebook</h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							Facebook on go.
						</p>
						</a>
				</div>
				<div class="main">
					<div class="banner box"><h3><a href="https://www.box.com" target="_blank">Box</a></h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							10GB minimum for your photos, videos, music, and documents.
						</p>
				</div>
				<div class="main">
					<div class="banner box"><h3><a href="https://www.box.com" target="_blank">Box</a></h3>
						<div class="overlay">
						</div>
						<i class="action">	
						</i>
					</div>
						<p class="caption">
							10GB minimum for your photos, videos, music, and documents.
						</p>
				</div>
			</div>
		</div>
		<!--/boday area-->
	</div>	
		
</div>
</body>
</html>
