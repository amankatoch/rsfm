<?php
session_start();

$mysql_host = "mobClick.db.10586791.hostedresource.com";
	$mysql_database = "mobClick";
	$mysql_user = "mobClick";
	$mysql_password = "PPass#0143";
	$con = mysql_connect($mysql_host,$mysql_user,$mysql_password);
	if(!$con){
		echo "connection error!!".mysql_error();
		die();
	}
	mysql_select_db($mysql_database, $con);
?>