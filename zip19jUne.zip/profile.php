<?php include_once "config/config.php";?>

<link href="css/jquery-ui-1.8.23.custom.css" rel="stylesheet">
<link rel="stylesheet" href="uploader/css/jquery.fileupload.css">
<link rel="stylesheet" href="uploader/css/jquery.fileupload.css">
<script src="//code.jquery.com/jquery-1.9.1.js"></script>
<script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
<link href="css/base.css" type="text/css" rel="stylesheet" />
<link href="css/twitter/bootstrap.css" rel="stylesheet">

<?php 

session_start();
 $userid=$_SESSION['user_id'];

    $q = "select * from user_registration where Id='$userid' limit 1";
	$result = mysql_query($q);
	while($run=mysql_fetch_array($result))
	{
		$userid=$run['Id'];
		$username=$run['Name'];
		$email=$run['Email'];
		$password=$run['Password'];

	}
	

    
  
   
   ?>
   
   <div id=row class=span12>
	  <div class=span3>
	  </div>
       <div class=span6>
        <h2>User Details</h2>  <h4><a href='index.php'>Back</a></h4>

       </div>
  </div>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <div id=row class=span12>
	  <div class=span3>
	  </div>
       <div class=span6>
		   <?php
		     echo '<label>User Name : '.$username.'</label>';
	         echo '<label>User Email : '.$email.'</label>';
	echo $password;
		   
		   ?>

       </div>
  </div>
   



	



	


