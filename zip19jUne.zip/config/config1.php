<?php
session_start();
$mysql_host = "pank0143.db.10586791.hostedresource.com";
	$mysql_database = "pank0143";
	$mysql_user = "pank0143";
	$mysql_password = "Pass#0143";
	$con = mysql_connect($mysql_host,$mysql_user,$mysql_password);
	if(!$con){
		echo "connection error!!".mysql_error();
		die();
	}
	mysql_select_db($mysql_database, $con);
 ?>
